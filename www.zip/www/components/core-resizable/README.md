core-resizable
============

See the [component page](https://www.polymer-project.org/0.5/docs/elements/core-resizable.html) for more information.
