core-animated-pages
===================

See the [component page](https://www.polymer-project.org/0.5/docs/elements/core-animated-pages.html) for more information.
