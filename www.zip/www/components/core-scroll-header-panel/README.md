core-scroll-header-panel
========================

See the [component page](https://www.polymer-project.org/0.5/docs/elements/core-scroll-header-panel.html) for more information.
