core-selection
==============

See the [component page](https://www.polymer-project.org/0.5/docs/elements/core-selection.html) for more information.
