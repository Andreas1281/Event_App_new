paper-fab
===================

See the [component page](https://www.polymer-project.org/0.5/docs/elements/paper-fab.html) for more information.
