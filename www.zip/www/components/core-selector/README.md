core-selector
==============

**This element is compatible with Polymer 0.5 and lower only, and will be deprecated.**  
You can check out a similar 0.8-compatible version of this element at [https://github.com/polymerelements/iron-selector](https://github.com/polymerelements/iron-selector)

See the [component page](https://www.polymer-project.org/0.5/docs/elements/core-selector.html) for more information.
