core-drawer-panel
==================

**This element is compatible with Polymer 0.5 and lower only, and will be deprecated.**  
You can check out a similar 0.8-compatible version of this element at [https://github.com/polymerelements/paper-drawer-panel](https://github.com/polymerelements/paper-drawer-panel)

See the [component page](https://www.polymer-project.org/0.5/docs/elements/core-drawer-panel.html) for more information.
