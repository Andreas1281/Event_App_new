core-scaffold
=============

See the [component page](https://www.polymer-project.org/0.5/docs/elements/core-scaffold.html) for more information.
