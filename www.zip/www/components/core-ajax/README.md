core-ajax
=========

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-ajax) for more information.
