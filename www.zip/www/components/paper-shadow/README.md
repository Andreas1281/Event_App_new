paper-shadow
============

See the [component page](http://polymer-project.org/docs/elements/paper-elements.html#paper-shadow) for more information.
